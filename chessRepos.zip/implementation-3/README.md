# simple-chess
A very simple C++ chess program for two human players. Playable locally or over a network. To start the game, run the following commands in the parent directory:
```
make compile

make run
```
