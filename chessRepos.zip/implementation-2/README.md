chess
=====

A C++ chess program.

This is a 2-player game, written for Object-Oriented Programming class.
